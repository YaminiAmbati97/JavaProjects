package com.cg.UI;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.beans.Customer;
import com.cg.beans.Customer.CustomerType;
import com.cg.beans.Product;
import com.cg.beans.Product.ProductType;
import com.cg.service.GroceryStoreService;
import com.cg.service.IGroceryStoreService;

public class Main {
	
	public static void main(String[] args) {
		Customer cust = null;
		Product prod1 = null;
		List<Product> products = null;
		IGroceryStoreService service = new GroceryStoreService();
		Scanner sc=new Scanner(System.in);
		System.out.println("_______________________________");
		System.out.println("Select type of Customer:\n 1.Employee of the store\n 2.Affiliate of the store\n 3.Customer for 2 years \n 4.Customer\n 5.Exit");
		System.out.println("_______________________________");
		int choice=sc.nextInt();
		switch(choice) {
			case 1:{
				cust = new Customer();
				cust.setCustomerType(CustomerType.EMPLOYEE);
				prod1 = new Product();
				System.out.println("Enter your Cusomter ID:");
				int customerID = sc.nextInt();
				cust.setCustomerID(customerID);
				System.out.println("Enter your Cusomter Name:");
				String customerName = sc.next();
				cust.setCustomerName(customerName);
				System.out.println("Enter the number of products:");
				int n = sc.nextInt();
				products = new ArrayList<Product>(n);
				for(int i=0;i<n;i++) {
					prod1 = new Product();
					System.out.println("Enter product type(1.Grocery 2.Toileteries 3.Other): ");
					int type = sc.nextInt();
					if(type==1) prod1.setProductType(ProductType.GROCERY);
					else if(type==2) prod1.setProductType(ProductType.TOILETERIES);
					else prod1.setProductType(ProductType.OTHER);
					System.out.println("Enter product Id: ");
					prod1.setProductID(sc.nextInt());
					System.out.println("Enter product Name: ");
					prod1.setProductName(sc.next());
					System.out.println("Enter product cost: ");
					prod1.setProductCost(sc.nextDouble());
					System.out.println("Enter product quantity: ");
					prod1.setQuantity(sc.nextInt());
					
					products.add(prod1);
				}
				cust.setProducts(products);
				double amountOnDiscount = service.getAmount(cust);
				System.out.println("Total Amount :"+amountOnDiscount);
				break;
			}
			case 2:{
				cust = new Customer();
				cust.setCustomerType(CustomerType.AFFILIATE);
				prod1 = new Product();
				System.out.println("Enter your Cusomter ID:");
				int customerID = sc.nextInt();
				cust.setCustomerID(customerID);
				System.out.println("Enter your Cusomter Name:");
				String customerName = sc.next();
				cust.setCustomerName(customerName);
				System.out.println("Enter the number of products:");
				int n = sc.nextInt();
				products = new ArrayList<Product>(n);
				for(int i=0;i<n;i++) {
					prod1 = new Product();
					System.out.println("Enter product type(1.Grocery 2.Toileteries 3.Other): ");
					int type = sc.nextInt();
					if(type==1) prod1.setProductType(ProductType.GROCERY);
					else if(type==2) prod1.setProductType(ProductType.TOILETERIES);
					else prod1.setProductType(ProductType.OTHER);
					
					System.out.println("Enter product Id: ");
					prod1.setProductID(sc.nextInt());
					System.out.println("Enter product Name: ");
					prod1.setProductName(sc.next());
					System.out.println("Enter product cost: ");
					prod1.setProductCost(sc.nextDouble());
					System.out.println("Enter product quantity: ");
					prod1.setQuantity(sc.nextInt());
					
					products.add(prod1);
				}
				cust.setProducts(products);
				double amountOnDiscount = service.getAmount(cust);
				System.out.println("Total Amount :"+amountOnDiscount);
				break;
			}
			case 3:{
				cust = new Customer();
				cust.setCustomerType(CustomerType.LONG_TIME_CUSTOMER);
				prod1 = new Product();
				System.out.println("Enter your Cusomter ID:");
				int customerID = sc.nextInt();
				cust.setCustomerID(customerID);
				System.out.println("Enter your Cusomter Name:");
				String customerName = sc.next();
				cust.setCustomerName(customerName);
				System.out.println("Enter the number of products:");
				int n = sc.nextInt();
				products = new ArrayList<Product>(n);
				for(int i=0;i<n;i++) {
					prod1 = new Product();
					System.out.println("Enter product type(1.Grocery 2.Toileteries 3.Other): ");
					int type = sc.nextInt();
					if(type==1) prod1.setProductType(ProductType.GROCERY);
					else if(type==2) prod1.setProductType(ProductType.TOILETERIES);
					else prod1.setProductType(ProductType.OTHER);
					
					System.out.println("Enter product Id: ");
					prod1.setProductID(sc.nextInt());
					System.out.println("Enter product Name: ");
					prod1.setProductName(sc.next());
					System.out.println("Enter product cost: ");
					prod1.setProductCost(sc.nextDouble());
					System.out.println("Enter product quantity: ");
					prod1.setQuantity(sc.nextInt());
					
					products.add(prod1);
				}
				cust.setProducts(products);
				double amountOnDiscount = service.getAmount(cust);
				System.out.println("Total Amount :"+amountOnDiscount);
				break;
			}
			case 4:{
				cust = new Customer();
				cust.setCustomerType(CustomerType.CUSTOMER);
				prod1 = new Product();
				System.out.println("Enter your Cusomter ID:");
				int customerID = sc.nextInt();
				cust.setCustomerID(customerID);
				System.out.println("Enter your Cusomter Name:");
				String customerName = sc.next();
				cust.setCustomerName(customerName);
				System.out.println("Enter the number of products:");
				int n = sc.nextInt();
				products = new ArrayList<Product>(n);
				for(int i=0;i<n;i++) {
					prod1 = new Product();
					System.out.println("Enter product type(1.Grocery 2.Toileteries 3.Other): ");
					int type = sc.nextInt();
					if(type==1) prod1.setProductType(ProductType.GROCERY);
					else if(type==2) prod1.setProductType(ProductType.TOILETERIES);
					else prod1.setProductType(ProductType.OTHER);
					
					System.out.println("Enter product Id: ");
					prod1.setProductID(sc.nextInt());
					System.out.println("Enter product Name: ");
					prod1.setProductName(sc.next());
					System.out.println("Enter product cost: ");
					prod1.setProductCost(sc.nextDouble());
					System.out.println("Enter product quantity: ");
					prod1.setQuantity(sc.nextInt());
					
					products.add(prod1);
				}
				cust.setProducts(products);
				double amountOnDiscount = service.getAmount(cust);
				System.out.println("Total Amount :"+amountOnDiscount);
				break;
			}
			case 5 : {
				System.out.println("Thank You, visit again.");break;
			}
			
			
		}//switch end

			
	}//main end
		 
	
}
