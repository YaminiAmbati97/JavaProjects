package com.cg.test;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.cg.beans.Customer;
import com.cg.beans.Product;
import com.cg.dao.GroceryStoreDAO;
import com.cg.dao.IGroceryStoreDAO;

@RunWith(JUnit4.class)
public class GroceryBillTest {
	private static IGroceryStoreDAO dao;
	private static Customer cust;
	private static Product prod;
	private static List<Product> products;
	//beforeall: executed once and before all tests in the class
	//before:executed before each method/test in the class
	
	@BeforeClass
    public static void setUp() {
		System.out.println("startup - init DAO");
		dao = new GroceryStoreDAO();
		cust = new Customer();
		prod= new Product();
		products = null;
    }
	
	@Before
	public void beforeEachTest() {
		products = new ArrayList<Product>(Arrays.asList( new Product(101, "Mirror", 50.0, 1, Product.ProductType.OTHER), new Product(102, "Bread", 30.0, 1, Product.ProductType.GROCERY),new Product(103, "Comb", 100.0, 1, Product.ProductType.TOILETERIES)  ));	
	}
	
	@SuppressWarnings("deprecation")
	@Test
	 public void testEmployeeBill() {
		 assertEquals(135, dao.getAmount(new Customer(1,"Bharath",Customer.CustomerType.EMPLOYEE,LocalDate.parse("2015-08-08"), products)));
	 }
	
	@SuppressWarnings("deprecation")
	@Test
	 public void testLongTimeCustomerBill() {
		 assertEquals(165, dao.getAmount(new Customer(2,"Yamini",Customer.CustomerType.AFFILIATE,LocalDate.parse("2015-09-09"),  products )));
	 }
	@SuppressWarnings("deprecation")
	@Test
	 public void testAffiliateBill() {
		
		 assertEquals(13954, dao.getAmount(new Customer(3,"Sravani",Customer.CustomerType.LONG_TIME_CUSTOMER,LocalDate.parse("2017-09-09"), products)));
	 }
	
	@SuppressWarnings("deprecation")
	@Test
	 public void testCustomerBill() {
		 assertEquals(13, dao.getAmount(new Customer(4,"Akshara",Customer.CustomerType.CUSTOMER,LocalDate.parse("2020-06-06"), products)));
	 }
	
	@After
	public void afterEachTest() {
		products = null;
	}
	@AfterClass
    public static void tearnDown() {
		System.out.println("startup - init DAO");
		dao = null;
		cust = null;
		prod= null;
		products = null;
    }
	

}
