package com.cg.service;

import com.cg.beans.Customer;

public interface IGroceryStoreService {
	public double getAmount(Customer customer);

}
