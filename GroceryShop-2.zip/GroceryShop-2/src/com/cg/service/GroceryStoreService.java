package com.cg.service;

import com.cg.beans.Customer;
import com.cg.dao.GroceryStoreDAO;
import com.cg.dao.IGroceryStoreDAO;

public class GroceryStoreService implements IGroceryStoreService{
	IGroceryStoreDAO dao = new GroceryStoreDAO();

	public double getAmount(Customer customer) {

		return dao.getAmount(customer);
	}

}
