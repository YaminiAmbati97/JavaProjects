package com.cg.dao;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;



import com.cg.beans.Customer;
import com.cg.beans.Product;

public class GroceryStoreDAO implements IGroceryStoreDAO{
	public double nonGrocProdAmount=0, grocProdAmount=0,totalAmount=0,amountOnDiscount=0 ;

	@Override
	public double getAmount(Customer customer) {		
		if(customer.getCustomerType() == Customer.CustomerType.EMPLOYEE) {
			List<Product> products = customer.getProducts() ;
			Iterator<Product> itr =  products.iterator();
			while(itr.hasNext()) {
				Product p =itr.next();
				if(p.getProductType()!=Product.ProductType.GROCERY) {
					nonGrocProdAmount += (p.getQuantity()*p.getProductCost());
				}
				else {
					grocProdAmount+=(p.getQuantity()*p.getProductCost());
				}		
			}
			totalAmount = (nonGrocProdAmount + grocProdAmount);
			amountOnDiscount = totalAmount - (nonGrocProdAmount*30)/100  ;
			//discount=totalWithoutGrocery*0.30;
			//finalPrice=(groceryAmount + totalWithoutGrocery)-discount;
		}else if(customer.getCustomerType() == Customer.CustomerType.AFFILIATE) {
			List<Product> products = customer.getProducts() ;
			Iterator<Product> itr =  products.iterator();
			while(itr.hasNext()) {
				Product p =itr.next();
				if(p.getProductType()!=Product.ProductType.GROCERY) {
					nonGrocProdAmount += (p.getQuantity()*p.getProductCost());
				}
				else {
					grocProdAmount+=(p.getQuantity()*p.getProductCost());
				}
				totalAmount = (nonGrocProdAmount + grocProdAmount);
				amountOnDiscount = totalAmount - (nonGrocProdAmount*10)/100  ;
			}
			
		}else if(customer.getCustomerType() == Customer.CustomerType.CUSTOMER){//everyday customers: 5% on every 100$
			totalAmount = (nonGrocProdAmount + grocProdAmount);
			int amount =(int) (totalAmount/100);
			double discount=amount*5;
			amountOnDiscount = totalAmount - (discount);//990/100=9.9 && 9*5=45$	
		}else {//long time customer
			List<Product> products = customer.getProducts() ;
			Iterator<Product> itr =  products.iterator();
			while(itr.hasNext()) {
				Product p =itr.next();
				if(p.getProductType()!=Product.ProductType.GROCERY) {
					nonGrocProdAmount += (p.getQuantity()*p.getProductCost());
				}
				else {
					grocProdAmount+=(p.getQuantity()*p.getProductCost());
				}
			}
			//int gap = LocalDate.now().getYear() - customer.getDate().getYear();
			//if(gap>=2) {
				totalAmount = (nonGrocProdAmount + grocProdAmount);
				amountOnDiscount = totalAmount - (nonGrocProdAmount*5)/100  ;
				
		}
		
		return amountOnDiscount;
	}

}
