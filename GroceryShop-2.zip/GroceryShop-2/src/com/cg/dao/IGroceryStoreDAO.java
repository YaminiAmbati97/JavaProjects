package com.cg.dao;

import com.cg.beans.Customer;

public interface IGroceryStoreDAO {
	public double getAmount(Customer customer);

}
