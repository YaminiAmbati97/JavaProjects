package com.cg.beans;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class Customer {
	
	public enum CustomerType {
		EMPLOYEE, AFFILIATE, LONG_TIME_CUSTOMER, CUSTOMER;
	}
	
	private int customerID;
	private String customerName;
	private CustomerType customerType;
	private LocalDate date;
	private List<Product> products =new ArrayList<Product>();
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public CustomerType getCustomerType() {
		return customerType;
	}
	public void setCustomerType(CustomerType customerType) {
		this.customerType = customerType;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	public Customer(int customerID, String customerName, CustomerType customerType, LocalDate date,
			List<Product> products) {
		super();
		this.customerID = customerID;
		this.customerName = customerName;
		this.customerType = customerType;
		this.date = date;
		this.products = products;
	}
	public Customer() {
		super();
	}
	

}
