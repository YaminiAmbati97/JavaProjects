package com.cg.beans;

public class Product {
	public enum ProductType {
		GROCERY,TOILETERIES, OTHER
	}
	private int productID;
	private String productName;
	private double productCost;
	private int quantity;
	private ProductType productType;
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getProductCost() {
		return productCost;
	}
	public void setProductCost(double productCost) {
		this.productCost = productCost;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public ProductType getProductType() {
		return productType;
	}
	public void setProductType(ProductType productType) {
		this.productType = productType;
	}
	public Product() {
		super();
	}
	public Product(int productID, String productName, double productCost, int quantity, ProductType productType) {
		super();
		this.productID = productID;
		this.productName = productName;
		this.productCost = productCost;
		this.quantity = quantity;
		this.productType = productType;
	}
	

}
