package com.cg.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.cg.beans.Match;
import com.cg.beans.Player;
import com.cg.beans.Team;
import com.cg.dao.MatchBO;
import com.cg.dao.PlayerBO;
import com.cg.dao.TeamBO;

public class Main {
public static void main(String[] args) throws IOException {
		
		PlayerBO s1 = new PlayerBO();
		TeamBO s2 = new TeamBO();
		MatchBO s3 = new MatchBO();
		Scanner sc = new Scanner(System.in);
		
		
		// Player Details
		System.out.println("Enter the number of players : ");
		int playerCount = sc.nextInt();
		Player[] players = new Player[playerCount];
		for(int i=1,pIdx=0;i<=playerCount;i++,pIdx++) {
			System.out.println("Enter player details :");
			String playerData=sc.next();
			Player p=s1.createPlayer(playerData);
			players[pIdx]=p;
			System.out.println(i+" player created");
		}
		//Enter team details
		System.out.println("Enter the team count :");
		int teamCount = sc.nextInt();
		Team[] teams = new Team[teamCount]; 
		for(int i=1,tIdx=0;i<=teamCount;i++,tIdx++) {
			System.out.println("Enter team details :");
			String teamData = sc.next();
			Team t = s2.createTeam(teamData, players);
			teams[tIdx] = t;
			System.out.println(i+ " team created");
		}
		//Enter match details
		System.out.println("Enter the match count : ");
		int matchCount = sc.nextInt();
		Match []matches = new Match[matchCount];
		for(int i=1,mIdx=0;i<=matchCount;i++,mIdx++) {
			System.out.println("Enter match  details :");
			String matchData = sc.next();
			Match m=s3.createMatch(matchData, teams);
			matches[mIdx] = m;
		}
		
		//s	
		while(true) {
		   System.out.println("");
           System.out.println("");
           System.out.println("");
           System.out.println("");
           System.out.println("");
           System.out.println("Select an option and press enter");
           System.out.println("_______________________________");
           System.out.println("1.Find Team");
           System.out.println("2.Find All Matches In A Specific Venue");
           System.out.println("3.If you dont want to continue.");
           System.out.println("_______________________________");
           int choice = sc.nextInt();
           switch(choice){
           case 1:{//find team by Match Date
        	    System.out.println("Enter Match date : ");
				String matchDate = sc.next();
				Team[] t = s3.findTeamsByMatchDate(matchDate, matches);
				System.out.println("Teams playing on  "+matchDate+"are: ");
				System.out.println(t[0].getTeamName()+","+t[1].getTeamName());
				break;
           }
           case 2:{
        	   System.out.println("Enter Team Name :");
			   String teamName = sc.next();
			   s3.findMatchesByTeamName(teamName, matches);
			   break;
           }
           case 3:{
        	 System.out.println("Thank you, Have a nice day");
             System.exit(0);
             break;
           }

        }
          
     }
		
		
  }
}
