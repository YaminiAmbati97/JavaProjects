package com.cg.beans;

public class Team {
	private String teamName;
	private Player teamPlayer;
	
	public Team() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Team(String teamName, Player teamPlayer) {
		super();
		this.teamName = teamName;
		this.teamPlayer = teamPlayer;
		
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public Player getTeamPlayer() {
		return teamPlayer;
	}
	public void setTeamPlayer(Player teamPlayer) {
		this.teamPlayer = teamPlayer;
	}
	
	

}
