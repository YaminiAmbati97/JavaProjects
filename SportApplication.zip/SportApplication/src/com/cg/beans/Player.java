package com.cg.beans;

public class Player {
	private String playerName;
	private String playerCountry;
	private String playerSkill;
	public Player() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Player(String playerName, String playerCountry, String playerSkill) {
		super();
		this.playerName = playerName;
		this.playerCountry = playerCountry;
		this.playerSkill = playerSkill;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public String getPlayerCountry() {
		return playerCountry;
	}
	public void setPlayerCountry(String playerCountry) {
		this.playerCountry = playerCountry;
	}
	public String getPlayerSkill() {
		return playerSkill;
	}
	public void setPlayerSkill(String playerSkill) {
		this.playerSkill = playerSkill;
	}
	@Override
	public String toString() {
		return "Player [playerName=" + playerName + ", playerCountry=" + playerCountry + ", playerSkill=" + playerSkill
				+ "]";
	}
	

}
