package com.cg.dao;

import com.cg.beans.Player;

public class PlayerBO {
	Player p = null;
	public Player createPlayer(String playerData) {
		p= new Player();
		String playerDetails[]=playerData.split(",");
		p.setPlayerName(playerDetails[0]);
		p.setPlayerCountry(playerDetails[1]);
		p.setPlayerSkill(playerDetails[2]);
		return p;	
	}

}
