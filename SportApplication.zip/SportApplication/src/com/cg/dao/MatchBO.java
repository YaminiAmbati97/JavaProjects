package com.cg.dao;

import com.cg.beans.Match;
import com.cg.beans.Team;

public class MatchBO {
	Match m = null;
	Team[] t =null;
	TeamBO tBO = null;
	//create match
	public Match createMatch(String matchData, Team[] teams) {
		m = new Match();
		Team t1=new Team();
		Team t2=new Team();
		String[] matchDetails = matchData.split(",");
		for(Team t:teams) {
			if(t.getTeamName().equals(matchDetails[1])) {
				t1.setTeamName(matchDetails[1]);
				break;
				}
		}	
		for(Team t:teams) {
			if(t.getTeamName().equals(matchDetails[2])) {
				t2.setTeamName(matchDetails[2]);
				break;
			}
		}
		m.setDate(matchDetails[0]);
		System.out.println(matchDetails[1]+"  "+matchDetails[2]);
		
		m.setTeamOne(t1);
		m.setTeamTwo(t2);
		String venue = matchDetails[3];
		m.setVenue(venue);
		return m;
	}
	//findTeams By match date
	public Team[] findTeamsByMatchDate(String matchDate,Match[] matchDetails) {
		t =new Team[2];
		m = new Match();
		for(Match m1 : matchDetails) {
			if(m1.getDate().equals(matchDate)) {
				t[0]=m1.getTeamOne();
				t[1]=m1.getTeamTwo();
				return t;
			}
		}
		return t;
	}
	//find all matches of team by team name
	public void findMatchesByTeamName(String teamName, Match[] matchDetails) {
		for(Match match :matchDetails) {
			if((match.getTeamOne().getTeamName().equals(teamName))) {
				System.out.println(match.getDate()+"\t"+match.getTeamOne().getTeamName()+"\t"+match.getTeamTwo().getTeamName()+"\t"+match.getVenue());
				break;
			}	
		}
		
		for(Match match :matchDetails) {
			if((match.getTeamOne().getTeamName().equals(teamName))) {
				System.out.println(match.getDate()+"\t"+match.getTeamOne().getTeamName()+"\t"+match.getTeamTwo().getTeamName()+"\t"+match.getVenue());
				break;
			}	
		}
	}
	
}
	