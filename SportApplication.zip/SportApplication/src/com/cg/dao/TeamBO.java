package com.cg.dao;

import com.cg.beans.Player;
import com.cg.beans.Team;

public class TeamBO {
	Team t =null;
	public Team createTeam(String teamData, Player players[]) {
		String[] teamDetails = teamData.split(",");
		t = new Team();
		t.setTeamName(teamDetails[0]);
		for(Player p : players) {
			if(p.getPlayerName().equals(teamDetails[1])) {
				t.setTeamPlayer(p);
				break;
			}
		}
		return t;
	}
	
	
	public Team findTeamByName(String teamName,Team[] teams) {
		for(Team t : teams) {
			if(t.getTeamName().equals(teamName)) {
				//System.out.println(t.getTeamName());
				return t;
			}
		}
		return t;
		
	}
}
