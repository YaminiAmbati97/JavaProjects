package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.beans.Employee;

public interface IEmployeeService {
	public boolean validateEmpId(String empId);
	public boolean validateSalary(double sal);
	public boolean validateName(String name);
	public boolean vaidateJoinDate(LocalDate date);
	
	public void createEmployee(Employee emp);
	public List<Employee> getEmployees();

}
