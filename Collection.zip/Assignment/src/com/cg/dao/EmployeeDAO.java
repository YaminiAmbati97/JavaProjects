package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.beans.Employee;

public class EmployeeDAO implements IEmployeeDAO{
	
	List<Employee> employees = new ArrayList<Employee>();

	@Override
	public void createEmployee(Employee emp) {
		employees.add(emp);
		System.out.println("Employee is created");
		
	}

	public List<Employee> getEmployees() {
		return employees;
	}

}
	